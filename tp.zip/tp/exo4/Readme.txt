Les problèmes :
l'envoie de n'importe quel fichier par le client audio, vidéo... 
Reception et recopie des octets du fichier envoyé sans corrompre le fichier initial

pour les résoudre on pourait lire le fichier au niveau du serveur en mode rb et au niveau de serveur ecrire 
en mode wb
