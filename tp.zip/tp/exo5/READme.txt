Nous serons ammenés à resoudre les problèmes de signaux envoyés périodiquement par le client
L'accès et modification de la mémoire partagée par les processus fils du serveur

Pour resoudre ce problème on pourrait utiliser les alarmes. Lorsque le le temps est ecroulé le serveur recoit le signal.
