/**
*Ce programme crée trois processus fils
* et affiche leur pid
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

int main(int argc, char **argv)
{
    pid_t pid1, pid2, pid3;
    int status;
    pid1 = fork();
    if(pid1 < 0){
         perror("Fail in creating child process !\n");
         exit(EXIT_FAILURE);
    }
    
    if(pid1 == 0){
        printf("Je suis le fils n° 1 voici mon pid %d\n", getpid());
        exit(1);//on l'arrete avec succes
    }else{
            pid2 = fork();
            if(pid2 < 0){
                 perror("Fail in creating child process !\n");
                 exit(EXIT_FAILURE);
             }
            if(pid2 == 0){
                printf("Je suis le fils n° 2 voici mon pid %d\n", getpid());
                exit(1);//on l'arrete avec succes
            }else{
                    pid3 = fork();
                    if(pid3 < 0){
                         perror("Fail in creating child process !\n");
                         exit(EXIT_FAILURE);
                     }
                    if(pid3 == 0){
                        printf("Je suis le fils n° 3 voici mon pid %d\n", getpid());
                        exit(1);//on l'arrete avec succes
                    }else{
                            printf("Moi cest le père voici mon pid %d et voici mes trois fils :\n ", getpid());
                            exit(1);
                    }
                 }
    }
    
	
	return 0;
}
