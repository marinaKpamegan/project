Les problèmes à resoudre

- la gestion des mémoires partagées 
- le calcul des cij par des processus
- accès controlée à la mémoire partagée par les processus

Pour les résoudre

- Nous aurons à créer trois mémoires partagées une pour les i, une pour les j et pour dernières pour les cij
  Nous allons initialiser la mémoire pour les cij à -1;
- Chaque processus auras à calculer les cij lorsque ceux ci sont égaux à -1
- Pour l'accès aux mémoires partagées chaque processus au moment d'utiliser la mémoire va la verrouiler une fois fini de modifier il la déverouille
