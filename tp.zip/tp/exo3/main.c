/**

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h> 
#include <sys/shm.h>  
#include <sys/sem.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>

#define MAX_SIZE 10
int main(int argc, char **argv)
{
    pid_t pid;
    int size, i, j, val, k, l = 0, c = 0, calcul = 0;;
      // clé pour la mémoire protégée
    key_t key1 = ftok("exo3",55);
    key_t key2 = ftok("exo3",68);
    key_t key3 = ftok("exo3",90);
    
    char *stri, *strj, *strCij;
    
    // On demande au system de creer la memoire partagee 
    int shmid1 = shmget(key1,1024,0666|IPC_CREAT); 
    int shmid2 = shmget(key2,1024,0666|IPC_CREAT);
    int shmid3 = shmget(key3,1024,0666|IPC_CREAT);
    // on attache la memoire partagee a stri, strj ,stri
   // stri = (char*) shmat(shmid1,(void*)0,0); 
    strj = (char*) shmat(shmid2,(void*)0,0); 
    stri = (char*) shmat(shmid3,(void*)0,0);
    
    
    //Creation de la matrice, creation et initialisation des mémoires partagées
     
	printf("Entrer la size de la matrice:\n");
	scanf("%d", &size);
	int matrice[size][size];
	int compteur = 0;
	
	for (i = 0; i < size; i++)
	{   
	     for (j = 0; j < size; j++)
	    {
	       printf("Element de la %d ligne et %d colonne:", i+1, j+1);
           scanf("%d", &val);
           matrice[i][j] = val;
           
           sprintf(strj + compteur , "%d",j);
        
           sprintf(stri + compteur , "%d", i);
           
           compteur++; 
	        
	    } 
	}
	
	//Affichage du contenu de la matrice
	printf("Matrice  entree :\n");
	
	 for (i = 0; i < size; i++)
	{
        for (j = 0; j < size; j++)
	    {
	        printf("%d ", matrice[i][j]);
	    } 
	    printf("\n");
	}
	printf("Stri entree %s:\n", stri);
	printf("Strj entree %s:\n", strj);
	
	//Créons des processus
	
	pid_t *tabproc = NULL;
	tabproc = malloc(sizeof((size * size) * sizeof(pid_t)));
	if(tabproc == NULL)
	{
	    perror ("Erreur de création tableau des processus");
	    exit(EXIT_FAILURE);
	}
    
    i = 0;
    do
    {
  
        pid = fork();
        if(pid < 0){
          perror("Erreur de création du processus\n");
          tabproc[i] = NULL;
          exit(EXIT_FAILURE);
        }
        if(pid ==0) 
        { }
       else
       {
           tabproc[i] = pid;
           printf("\nLe pid de mon fils %d", tabproc[i]);}
        
        i++;
       
    }while(i < size * size);
    
    //Calcul du carre de la matrice
    
    int strI, strJ;
    int moinsun = 0;
    
  
    printf("Calcul du carre de la matrice\n");
	 for(i = 0; i < size; i++)//ligne de la matrice
    {
        for(j = 0; j < size; j++)//colonne de la matrice
        {
           
            for( compteur = 0; compteur < size * size; compteur++)
            {
                if(atoi(stri + compteur) == -1)
                {
                    moinsun = 1;
                    strI = atoi(stri + compteur);
                    strJ = atoi(strj + compteur);
                    break;
                }
                else{ moinsun = 0; }
            }
            
            if(moinsun)
            {
                for(k = 0; k < size; k++)//ligne * colonne
                {
                    calcul += matrice[strI][k] * matrice[k][strJ];
                   
                }
                 printf("Calcul %d\n", calcul);
                sprintf(stri + compteur , "%d", compteur);
            }
                  
        }
    }
	// affichage du contenu de
	printf("\n%s", stri);
	
	//char *argp[] = NULL; 
    int tmp = 0;
    int calc = 0;
    compteur = 0;
   
    free(tabproc);
    //le processus détache str de la mémoire partagée 
    shmdt(stri); 
    shmdt(strj); 
    shmdt(stri); 
    // destruction de la mémoire 
    shmctl(shmid1,IPC_RMID,NULL);
    shmctl(shmid2,IPC_RMID,NULL);
    shmctl(shmid3,IPC_RMID,NULL);
    // des truction du semaphore
  /*  if(semctl(semid1, 0, IPC_RMID, NULL) == -1 || semctl(semid2, 0, IPC_RMID, NULL) == -1 || semctl(semid3, 0, IPC_RMID, NULL) == -1){
       perror("semctl");
       exit(1);
    	}*/	
	
	return 0;
}
